package launcher;


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;


public class MovieOptions extends Application
{
        Stage window;
        ArrayList<Movie> moviesCreated = new ArrayList<>();
@Override
public void start(Stage stage) {
        window = stage;
        stage.setTitle("Our first Java FX program");
        stage.setScene(optionScene());
        stage.show();
        }

public Scene formScene()
        {
        //create panel to hold widgets
        VBox big = new VBox(); // Entire Panel

        HBox line1 = new HBox(); //text Panel
        HBox line2 = new HBox(); //combo Panel
        HBox line3 = new HBox(); //combo Panel
        HBox line4 = new HBox(); //radio box Panel
        HBox line5 = new HBox(); //button Panel
        HBox line6 = new HBox(); //Nav buttons


        //create widgets
        //labels
        Label title = new Label("Title");
        Label genre = new Label("Genre");

        Label year = new Label("Year");
        Label release = new Label("Release in theatre");
        Label poster = new Label("Poster");

        //controls
        TextField titlef = new TextField();

        ObservableList<String> genreItems = FXCollections.observableArrayList("Action","Horror","Comedy",
        "Romance","Historical","War", "Drama");
        ComboBox genref = new ComboBox();
        genref.getItems().addAll(genreItems);
        genref.setPrefWidth(150);

        ObservableList<Integer> yearItems = FXCollections.observableArrayList();
        for (int i = 1900; i<=2019; i++)
        {
        yearItems.add(i);
        }
        ComboBox yearf = new ComboBox();
        yearf.getSelectionModel().getSelectedItem();
        yearf.getItems().addAll(yearItems);
        yearf.setPrefWidth(150);


        RadioButton releasef = new RadioButton("Yes");
        releasef.setPrefWidth(50);
        RadioButton releasefn = new RadioButton("No");
        releasefn.setPrefWidth(50);
        ToggleGroup inTheatre = new ToggleGroup();
        releasef.setToggleGroup(inTheatre);
        releasefn.setToggleGroup(inTheatre);
        boolean goTooMovies;
        if (inTheatre.getSelectedToggle().equals("Yes"))
        {

        }
        boolean inDaClub = inTheatre.getSelectedToggle();
        HBox inTheatreOptions = new HBox();
        inTheatreOptions.getChildren().addAll(releasef,releasefn);
        inTheatreOptions.setPrefWidth(125);
        inTheatreOptions.setSpacing(15);

        Button posterf = new Button("+");
        posterf.setPrefWidth(50);

        TextField postLocation = new TextField();

        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File("./assets"));
        fileChooser.setTitle("Choose a Poster Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files","*.jpg")
        );
        posterf.setOnAction(e -> {
                File selected = fileChooser.showOpenDialog(window);
                if (selected != null)
                {
                        String namebo = selected.getName();
                        postLocation.setText(namebo);
                }
        });

        postLocation.setPrefWidth(150);
        HBox posterSpecs = new HBox();
        posterSpecs.getChildren().addAll(posterf, postLocation);

        stylePanel(posterSpecs);

        Button navBack = new Button("Back");
        navBack.setPrefSize(100, 50);

//        Stage window = new Stage();
        navBack.setOnAction(e-> window.setScene(optionScene()));
        Button saveMovie = new Button("Save Movie");
        saveMovie.setOnAction(e-> window.setScene(optionScene()));
        saveMovie.setOnAction(e->

                Movie movie = new Movie(String.valueOf(titlef),String.valueOf(genref),Integer.valueOf(yearf),true,postLocation);
                );
        saveMovie.setPrefSize(100,50);

        //set styles for the panels
        big.setAlignment(Pos.CENTER_LEFT);
        big.setPadding(new Insets(20,10,10,20));
        big.setSpacing(5);

        stylePanel(line1);
        stylePanel(line2);
        stylePanel(line3);
        stylePanel(line4);
        stylePanel(line5);
        stylePanel(line6);
        line6.setAlignment(Pos.CENTER_RIGHT);

        //set styles for widgets
        foldWidget(title,titlef);
        foldWidget(genre, genref);
        foldWidget(year, yearf);
        foldWidget(release, inTheatreOptions);
        foldWidget(poster, posterSpecs);

        //add widgets to the panel
        line1.getChildren().addAll(title,titlef);
        line2.getChildren().addAll(genre, genref);
        line3.getChildren().addAll(year, yearf);
        line4.getChildren().addAll(release, inTheatreOptions);
        line5.getChildren().addAll(poster, posterSpecs);
        line6.getChildren().addAll(saveMovie,navBack);

        big.getChildren().addAll(line1, line2, line3, line4, line5, line6);

        //display elements of scene
        return new Scene (big,450,400);
        }

public Scene optionScene()
        {
        //create panel to hold widgets
        VBox big = new VBox(); // Entire Panel

        //create widgets
//        Stage window = new Stage();

        //controls
        Button addMovie = new Button("Add a New Movie");
        addMovie.setOnAction(e -> window.setScene(formScene()));
        Button viewMovie = new Button("View All Movies");
        viewMovie.setOnAction(go-> window.setScene(listOfMoviesScene()));
        //set styles for the panels
        big.setAlignment(Pos.CENTER);
        big.setSpacing(20);

        //set styles for widgets
        addMovie.setPrefWidth(150);
        addMovie.setPrefHeight(45);
        viewMovie.setPrefWidth(100);
        viewMovie.setPrefHeight(45);

        //add widgets to the panel
        big.getChildren().addAll(addMovie, viewMovie);

        //display elements of scene
        return new Scene (big,450,300);
        }

public Scene listOfMoviesScene()
{
        VBox big = new VBox();
        ListView mlist = new ListView();
        mlist.setPrefSize(300, 100);
        HBox picNText = new HBox();
        picNText.setSpacing(10);

        //Controls
        big.setAlignment(Pos.CENTER);
        Image pic = new Image();
        Label title = new Label();
        Label Genre = new Label();
        Label year = new Label();
        Label theatre = new Label();



        //widgets
        title.setLabelFor(ContentDisplay);


        Button navBack = new Button("Back");
        navBack.setPrefSize(100, 50);
        navBack.setOnAction(e-> window.setScene(optionScene()));

        big.getChildren().addAll(navBack);
        //display elements of scene
        return new Scene (big,450,300);
}

private void stylePanel(HBox p)
{
        p.setAlignment(Pos.CENTER_LEFT);
        p.setSpacing(10);
        p.setPadding(new Insets(10,30,10,30));
        p.setPrefHeight(30);
}

private void styleWidget(Label x)
        {
        x.setAlignment(Pos.CENTER_LEFT);
        x.setPadding(new Insets(0,15,0,10));
        x.setPrefWidth(150);
        }

private void foldWidget(Label x, Node node)
        {
        styleWidget(x);
        x.setLabelFor(node);
        }


}