package launcher;

public class Movie {
    private String title;
    private String genre;
    private int year;
    private boolean theatre;
    private String posterPath;

    Movie(String title, String genre, int year, boolean theatre, String posterPath)
    {
        this.title = title;
        this.genre = genre;
        this.year = year;
        this.theatre = theatre;
        this.posterPath = posterPath;
    }
    //accessors
    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }

    public boolean isTheatre() {
        return theatre;
    }

    public String getPosterPath() {
        return posterPath;
    }

    //mutator
    public void setTitle(String title) {
        this.title = title;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setTheatre(boolean theatre) {
        this.theatre = theatre;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }
}
