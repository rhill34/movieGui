package launcher;


import javafx.application.Application;
import javafx.stage.Stage;

import java.io.File;

public class Launcher
{


    public static void main(String[] args)
    {
        Application.launch(MovieOptions.class, null);
    }
}
