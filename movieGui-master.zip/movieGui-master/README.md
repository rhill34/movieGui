# movieGui
Greenriver IT301 project using JavaFX to create a mock Movie GUI Application.
